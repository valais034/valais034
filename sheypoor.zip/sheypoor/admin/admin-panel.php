<?php  include 'header.php' ?>
<div align="center">
<ul style="line-height:100px;">
<li><a href="show-users.php" style="color:red;">مدیریت کاربران</a></li>
<li>مدیریت آگهی ها</li>
<li><a href="ostan-managment.php" style="color:red;">مدیریت استان ها</a></li>
<li><a href="support-show.php" style="color:red;">پشتیبانی</a></li>

</ul>
</div>
<?php  include 'footer.php' ?>