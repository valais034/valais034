<!------START OF FOOTER------->
<div id="footer">
	<div id="footer_right">
		<div id="footer_right_1">
			<a href="">درباره شیپور</a>
			|
			<a href="">قوانین و مقررات</a>
			|
			<a href="">سیاست حفظ حریم شخصی</a>
			|
			<a href="">ارسال پیشنهادات</a>
			|
			<a href="">بلاگ</a>
		</div>
		<div id="footer_right_2">
			<img src="images/bazar.PNG">
			<img src="images/store.PNG">
		</div>
		<div id="footer_right_3">کليه حقوق اين سایت متعلق به شرکت نت تجارت اهورا (شیپور) است.</div>
	</div>
	<div id="footer_left">
		
		<div id="footer_left_1"><img src="images/namad.png"></div>
		<div id="footer_left_2">Copyright © 2016 - www.sheypoor.com</div>
	</div>
	
</div>
<!------END OF FOOTER------->