<?php include 'header.php';?>
<div align="center" style="font-size: 25px;font-weight: bold;margin-bottom: 20px;"> آگهی های من</div>
<div align="center" style="color: #424141">  آگهی‌های شما در این صفحه نمایش داده می‌شوند. </div>
<div align="center" style="margin-bottom: 170px;"><form action="register-agahi.php" method="post"><input type="submit" value="اولین آگهی خود را ثبت نمایید"  class="agahibtn"></form></div>
<?php include 'footer.php';?>