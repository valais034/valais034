<?php
$connect=new PDO("mysql: host=localhost;dbname=sheypoor","root","");
$connect->exec("set names utf8");
?>